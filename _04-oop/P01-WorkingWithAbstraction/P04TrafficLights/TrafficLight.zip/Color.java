package P04TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
